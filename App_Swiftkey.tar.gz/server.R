library(shiny)
require(dplyr)
require(stringi)
require(tm)
require(data.table)

# load data model
load("data/grams.Rdata")

# clean function
clean.data = function(x) {
  x %>% 
    tolower() %>% 
    stri_trans_general(., "Latin-ASCII") %>% 
    iconv(., "UTF-8", "ASCII//TRANSLIT") %>% 
    gsub("-", " ", .) %>%
    removePunctuation() %>% 
    removeNumbers() %>% 
    removeWords(., stopwords("english")) %>% 
    gsub("_", " ", .) %>% 
    gsub("aaa", "", .) %>% 
    gsub("aa", "", .) %>% 
    stripWhitespace() %>% 
    strsplit(., " ") %>% 
    unlist() -> x
  return(x)
}

# funcao de predicao
predicao.funcao = function(db.limpo) {
  if (db.limpo %>% length() > 0) {
    
    db.last = db.limpo[db.limpo %>% length()]
    db.last = paste0("^", db.last)
    previsao = grams[grep(db.last, grams$V1), 1:2]
    if (nrow(previsao) > 10) {
      previsao = previsao[1:10, ]
    }
    
    if (is.na(previsao[1]) == T) {
      previsao = c("the", "the") %>% t()
      }
    
  } else {
    
    previsao = c("the", "the") %>% (t)
    
  }
  return(previsao)
}

shinyServer(function(input, output) {
  
  observe({
    
    db.limpo = input$texto.entra %>% clean.data()
    
    # ajustando a entrada
    previsao = predicao.funcao(db.limpo)
    previsao %>% as.data.frame() -> previsao
    names(previsao) = c("Current word", "Next word")
    
    output$resultado.predicao = renderTable(previsao)
    
  })
   
})
