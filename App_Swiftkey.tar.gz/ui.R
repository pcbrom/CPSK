library(shiny); library(shinythemes)

shinyUI(fluidPage(
    theme = shinytheme("superhero"),
    titlePanel(""),
    sidebarLayout(
        sidebarPanel(
            
            width = 3,
            
            img(src = "250-250.png", height = 270, width = "100%"),
  
            h6("*****************************************", align = "center"),
            h6(strong("DEVELOPMENT"), align = "center"),
            h6("Pedro Carvalho Brom", align = "center"),
            h6("supermetrica@gmail.com", align = "center"),
            h6(a("facebook.com/supermetrica", href = "https://www.facebook.com/supermetrica", target="_blank"), align = "center"),
            h6(a("supermetrica.blogspot.com.br", href = "https://supermetrica.blogspot.com.br", target="_blank"), align = "center"),
            h6(a("github.com/pcbrom", href = "https://github.com/pcbrom", target="_blank"), align = "center"),
            h6("*****************************************", align = "center")
            
        ),
        
        mainPanel(
            
            textInput("texto.entra", "Enter text", value = ""),
            tableOutput("resultado.predicao")
            
        )
    )
))
